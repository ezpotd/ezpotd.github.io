function copy(){ 
  var copyText = document.getElementById("my");
  copyText.select();
  var a = copyText.value;
  var b = "";
  
  for(var i = 0; i < a.length; i++){
    if(i % 2 == 0){
      b += a.charAt(i).toLowerCase();
    }
    else{
      b += a.charAt(i).toUpperCase();
    }
  }
  navigator.clipboard.writeText(b);
}
var button = document.getElementById("button");
button.addEventListener("click", async () => {
  copy();
});